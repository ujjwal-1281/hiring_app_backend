package com.project.repository;

import com.project.enities.EducationEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EducationRepo extends JpaRepository<EducationEntity,Long> {
}
